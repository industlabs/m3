/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

var debug=0;
var cdeUP = 0;
var cdeStopUP = 1;
var cdeDOWN = 2;
var cdeStopDOWN = 3;
var cdeLEFT = 4;
var cdeStopLEFT = 5;
var cdeRIGHT = 6;
var cdeStopRIGHT = 7;
var flagMoveRight=0;
var flagMoveLeft=0;
var flagMoveUp=0;
var flagMoveDown=0;
var flagTakePhoto=0;
var ipRouteur='';
var userConnected='';
var loginEnCours=0;
var cdeEnCours=''
var refrefresh_gpio=false;
var progress_connection='Connecting';
var progressUpdatingLibelle=0;
var timerUpdatingLibelle;
var timeoutConnection=0;
var timeoutUpdatingLibelle=0;
var errorcon=0;
var connected=0;
var loginConfigLibelles=0;
var indexLibelle=0;
var indexLibelleBit=0;
var blocSlx=new Uint16Array(60);
var mouseX;
var mouseY;
var captMouseX=0;
var captMouseY=0;
var mouveDetailBitsSL=0;
var posLeftdetailBitsSL=20;
var posTopdetailBitsSL=100;

function activeCapturePosSouris(){
	document.addEventListener("mousemove", onMouseMove, false);
}

function desactiveCapturePosSouris(){
	document.removeEventListener("mousemove", onMouseMove);  
}

function getScrollXY() {
    var x = 0, y = 0;
    if( typeof( window.pageYOffset ) == 'number' ) {
        // Netscape
        x = window.pageXOffset;
        y = window.pageYOffset;
    } else if( document.body && ( document.body.scrollLeft || document.body.scrollTop ) ) {
        // DOM
        x = document.body.scrollLeft;
        y = document.body.scrollTop;
    } else if( document.documentElement && ( document.documentElement.scrollLeft || document.documentElement.scrollTop ) ) {
        // IE6 standards compliant mode
        x = document.documentElement.scrollLeft;
        y = document.documentElement.scrollTop;
    }
    return [x, y];
}
function onMouseMove(e) {
	mouseX = e.clientX;
	mouseY = e.clientY;
	if (debug==1) console.log("xPos="+mouseX+" yPos="+mouseY);
	var posXY=getScrollXY();
	
	if (mouveDetailBitsSL==1){		
		posLeftdetailBitsSL+=(mouseX-captMouseX);
		captMouseX=mouseX;
		posTopdetailBitsSL+=(mouseY-captMouseY);
		captMouseY=mouseY;
		posdetailBitsSL(posLeftdetailBitsSL,posTopdetailBitsSL);
	}
}

function posdetailBitsSL(left,top){
	if (left>20) document.getElementById("detailBitsSL").style.left=left+"px";
	document.getElementById("detailBitsSL").style.top=top+"px";
}

function ClickDownDetailBitsSL(){
	captMouseX=mouseX;
	captMouseY=mouseY;
	if (debug==1) console.log("xcapPos="+captMouseX+" yPcapos="+captMouseY);
	mouveDetailBitsSL=1;
	document.getElementById("detailBitsSL").style.cursor="hand";
	document.getElementById("detailBitsSL").style.opacity=0.8;
}

function ClickUpDetailBitsSL(){
	
	mouveDetailBitsSL=0;
	document.getElementById("detailBitsSL").style.cursor="default";
	document.getElementById("detailBitsSL").style.opacity=1;
}


function prefixZeros(numberStr, maxDigits) 
{  
    var length = maxDigits - numberStr.length;
    if(length <= 0)
    	return numberStr.toUpperCase();

    var leadingZeros = new Array(length + 1);
    return leadingZeros.join('0') + numberStr.toUpperCase();
}

function checkInputVal(inputSL){                
    var valInput=document.getElementById(inputSL).value;
    if(parseInt(valInput, 10) >= 0) {
        if ((valInput>=0)&&(valInput<=65535));else
        alert("la valeur doit etre comprise entre 0 et 65535");
    }else {
        alert("La valeur saisie est incorrecte.");  
        document.getElementById(inputSL).value="0";
    }
}

function addLigneSLW(numLigne){	
		var myligne="<th>SL"+numLigne+"</th>";		
		myligne+="<td><img src=\"images/exclamation.png\" width=\"20\" height=\"20\"  id=\"imgUpdateLib"+numLigne+"\" /></td>"
		myligne+="<td><input class=\"inputSLxText\" id=\"inputSL"+numLigne+"_text\" type=\"text\" maxlength=\"30\" onkeyup=\"changeTextSL("+numLigne+",\'inputSL"+numLigne+"_text\',event)\"/></td>";
        myligne+="<td><div align=\"center\" id=\"SL"+numLigne+"_Dec\">-</div></td>";
        myligne+="<td><div align=\"center\" id=\"SL"+numLigne+"_Hex\">-</div></td>";
        myligne+="<td><div class=\"binaryField\" onclick=\"showdetailBitsSL("+numLigne+")\" align=\"center\" id=\"SL"+numLigne+"_Bin\">-</div></td>";
        myligne+="<td><input class=\"inputSLx\" id=\"inputSL"+numLigne+"_new\" type=\"number\" min=\"0\" max=\"65535\" onkeyup=\"checkInputVal(\'inputSL"+numLigne+"_new\')\"/></td>";
        myligne+="<td><button id=\"WriteSL"+numLigne+"\" onclick=\"writeSLx("+numLigne+",\'inputSL"+numLigne+"_new\')\" >Write SL"+numLigne+"</button></td>";
    	myligne+="</tr>";
    	document.write(myligne);
}

function addLigneSLR(numLigne){
	var myligne="<tr><th>SL"+numLigne+"</th>";
	myligne+="<td><img src=\"images/exclamation.png\" width=\"20\" height=\"20\"  id=\"imgUpdateLib"+numLigne+"\" /></td>"
	myligne+="<td><input class=\"inputSLxText\" id=\"inputSLR"+numLigne+"_text\" type=\"text\" maxlength=\"30\" onkeyup=\"changeTextSL("+numLigne+",\'inputSLR"+numLigne+"_text\',event)\"/></td>";
	myligne+="<td><div align=\"center\" id=\"SL"+numLigne+"_Dec\">-</div></td>";
    myligne+="<td><div align=\"center\" id=\"SL"+numLigne+"_Hex\">-</div></td><td><div class=\"binaryField\" onclick=\"showdetailBitsSL("+numLigne+")\"  align=\"center\" id=\"SL"+numLigne+"_Bin\">-</div></td></tr>";   
	document.write(myligne);
}

function createRowsSL_RW(numFirstRow,numLastRow){
	var i=0;
	for(i=numFirstRow;i<=numLastRow;i++){
		addLigneSLW(i);
	}
}	
function createRowsSL_R(numFirstRow,numLastRow){
	var i=0;
	for(i=numFirstRow;i<=numLastRow;i++){
		addLigneSLR(i);
	}
}	



function hide_show_Col(idtable,col) {  
	var show=0;   
	       
    var tbl;
    if (document.getElementById(idtable+"_col_"+col).checked){
    	show=1;
    }else show=0;
    tbl = document.getElementById(idtable);	            	            
    if (tbl != null) {
        if (col < 0 || col >= tbl.rows.length - 1) {
            alert("Invalid Column");
            return;
        }
        //tbl.rows.length = nombre de lignes dans la table
        //tbl.rows[i].cells.length = nombre de cellules dans la ligne i
        for (var i = 0; i < tbl.rows.length; i++) {
            for (var j = 0; j < tbl.rows[i].cells.length; j++) {	                        
                if (j == col)
                	if (show==0)
                    tbl.rows[i].cells[j].style.display = "none";
                    else
                    tbl.rows[i].cells[j].style.display = "table-cell";
            }
        }
    }
}

function changeTextSL(numSL,inputSLText,evt){
	              
    var valInput=document.getElementById(inputSLText).value;
    var res = valInput.charAt(valInput.length-1);
    var charCode = (evt.which) ? evt.which : evt.keyCode
	var ctrlPressed=0;
 	var altPressed=0;
 	var shiftPressed=0;
 	
 	shiftPressed=evt.shiftKey;
 	altPressed  =evt.altKey;
 	ctrlPressed =evt.ctrlKey;    
	switch	(charCode)
	{
		case 13:
			if (altPressed){
				if (debug==1) console.log("RtextSL"+numSL+"="+(valInput));
				if (connected==1) {
					document.getElementById("imgUpdateLib"+numSL).src="images/clock.png";
					sendMessage("RtextSL"+numSL+"?");					
				}
			}else{
				if (debug==1) console.log("WtextSL"+numSL+"="+(valInput));
				if (connected==1) {			
					document.getElementById("imgUpdateLib"+numSL).src="images/clock.png";		
					sendMessage("WtextSL"+numSL+"="+(valInput));		
				}		
			}
			
		break;
	}	    
}

function writeSLx(adr,inputSL){
    var valInput=document.getElementById(inputSL).value;  
    if(parseInt(valInput, 10) >= 0) {
        if ((valInput>=0)&&(valInput<=65535)){
            //alert("m3_Ww(" + adr + "," + valInput + ")"); 
            sendCdeIO("m3_Ww(" + adr + "," + valInput + ")"); 
        }
        else
        alert("la valeur doit etre comprise entre 0 et 65535");
    }else {
        alert("La valeur saisie est incorrecte.");  
        document.getElementById(inputSL).value="0";
    }
}	


function loginUP() {
var btnImg;
    if (connected==1)return;
    if (loginEnCours==0) {
    	loginEnCours=1;
		loginToCam();
    }
}

function sendCdeIO(cde) {		    	
    ws.send(cde);
}

//*************************************************************************	
// Initialize WebSocket connection and event handlers
function setup() {
    if (ipRouteur=="-"){
        alert("Login fail");
        return;
    }
    ws = new WebSocket("ws://"+ipRouteur+":1061/");			
    ws.binaryType = "arraybuffer";

    // Listen for the connection open event then call the sendMessage function
    ws.onopen = function (e) {        
        //document.getElementById("captionTableReadWrite").innerHTML="SLin/SLout remote control connected";
        document.getElementById("loginM3").style.visibility="hidden";
		document.getElementById("Bloc_SL1_24").style.visibility="visible";
		document.getElementById("Bloc_SL25_48").style.visibility="visible";		
		var ledImg=document.getElementById("stateCon");
		ledImg.src="images/Green_2.png";
        connected=1;
        sendMessage("RtextSL1?");
        activeCapturePosSouris();
    }

    // Listen for the close connection event
    ws.onclose = function (e) {        
        //document.getElementById("captionTableReadWrite").innerHTML="SLin/SLout remote control disconnected";
        document.getElementById("conWebsocket").innerHTML="Connect";
        var ledImg=document.getElementById("stateCon");
		ledImg.src="images/Gray_2.png";
        connected=0;
        desactiveCapturePosSouris();
        alert("System disconnected");
    }

    // Listen for connection errors
    ws.onerror = function (e) {        
        document.getElementById("captionTable").innerHTML="SLin/SLout remote control error";        
    }

    // Listen for new messages arriving at the client
    ws.onmessage = function (e) {
       
        //log("Mensaje recibido del servidor: " + e.data);             
        if (e.data instanceof ArrayBuffer) {                
            var arrayBuffer = e.data;
            var blocBytesSlx = new Uint8Array(arrayBuffer);
            
            var lenarray=blocBytesSlx.length;
            if (debug==1) console.log("len=" + lenarray);			
            if ((lenarray==110)&&(blocBytesSlx[0]==0x0A)&&(blocBytesSlx[1]==0xA0)){                  
                var j=1;
                for (var i=1;i<=96;i+=2){					
                        blocSlx[j]=(blocBytesSlx[i+1]<<8)+blocBytesSlx[i+2];	
                        if (j<=48){
                        	document.getElementById("SL"+j+"_Dec").innerHTML=blocSlx[j];
                			document.getElementById("SL"+j+"_Hex").innerHTML=prefixZeros(Number(blocSlx[j]).toString(16),4);
                			document.getElementById("SL"+j+"_Bin").innerHTML=prefixZeros(Number(blocSlx[j]).toString(2),16);
                			if (j>=25){
	                			if (document.getElementById("detailBitsSL").style.visibility=="visible"){
	                        		var SLsel=document.getElementById("BitsSLxSel").innerHTML;
									var numSL=parseInt(SLsel,10);
									if (debug==1) console.log("showBitsSL "+numSL);
	                        		if (numSL==j) {
	                        			showBitsSL(j);
	                        			if (debug==1) console.log("showBitsSL "+j);
	                        		}
	                        	}
                        	}
                        }			
                        j++;
                }                    
            }
        }else if (typeof e.data == "string") {
        	log("Mensaje recibido del servidor: " + e.data); 
			var infoRet=e.data;
			var pos_infoSL=infoRet.indexOf("infoSL");		
			var pos_sign_equal=infoRet.indexOf("=");			
			var numSL="0";
			if (pos_infoSL>=0){	
				if (pos_sign_equal>0){
					numSL=infoRet.match(/\d+/g); 						
					var tabId = infoRet.split("=").pop();
					if (debug==1) console.log("inputSL"+numSL[0]+"_text");
					if (tabId.length<=30){
						var x = parseInt(numSL[0],10);
						if ((x>0)&&(x<=24)){
							;document.getElementById("inputSL"+numSL[0]+"_text").value=tabId;
							document.getElementById("imgUpdateLib"+numSL[0]).src="images/check_mark.png";
						}else if ((x>24)&&(x<=48)){
							;document.getElementById("inputSLR"+numSL[0]+"_text").value=tabId;
							document.getElementById("imgUpdateLib"+numSL[0]).src="images/check_mark.png";
						}
					}																		
				}	
				indexLibelle++;
				if (debug==1) console.log(indexLibelle);
				if (indexLibelle<=48){			
					document.getElementById("imgUpdateLib"+indexLibelle).src="images/clock.png";		
					sendMessage("RtextSL"+indexLibelle+"?");		
					if (debug==1) console.log("RtextSL"+indexLibelle+"?");		
				}else indexLibelle=49;
			}else{
				var pos_infoBit=infoRet.indexOf("infoBit");		
				pos_sign_equal=infoRet.indexOf("=");
				if (pos_infoBit>=0){	
					if (pos_sign_equal>0){		
						var reg=new RegExp("[_=]+", "g");
						var tableau=infoRet.split(reg);
						if (tableau.length>=3){
							var infoText=tableau[3];
							for (var i=4; i<tableau.length; i++) {
 								infoText+="_"+tableau[i];
							}	
							document.getElementById("inputBitsSL"+tableau[2]+"_text").value=infoText;
							document.getElementById("imgUpdateLibBitsSL"+tableau[2]).src="images/check_mark.png";							
						}
						
					}					
					if (indexLibelleBit<=15){	
						var SLsel=document.getElementById("BitsSLxSel").innerHTML;
						var numSL=parseInt(SLsel,10);		
						document.getElementById("imgUpdateLibBitsSL"+indexLibelleBit).src="images/clock.png";		
						sendMessage("RinfoBit"+numSL+"_"+indexLibelleBit+"?");		
						if (debug==1) console.log("RinfoBit"+numSL+"_"+indexLibelleBit+"?");		
					}else indexLibelleBit=16;
					indexLibelleBit++;					
				}
			}				
        }
    }
}
//*************************************************************************

// Send a message on the WebSocket.
function sendMessage(msg) {
    ws.send(msg);
    log("Mensaje enviado");
}

// Display logging information in the document.
function log(s) {
    if (debug==1) console.log(s);
}

function Horloge() {
var dt=new Date();
    //window.status=dt.getHours()+":"+dt.getMinutes()+":"+dt.getSeconds();
    progress_connection=progress_connection + "."
    //document.getElementById("infoConnection").innerHTML=progress_connection;
    timeoutConnection++;
    document.getElementById("infoConnection").innerHTML=progress_connection;
    if ((timeoutConnection % 5)==0) progress_connection="Connection.";
    if (timeoutConnection>30)
    {    	
        document.getElementById("infoConnection").innerHTML="Connection error";
        
    }
}

function loginToCam()
{
    var login=document.getElementById("textUser").value;
    var pwd=document.getElementById("textPassword").value;
    var timer=setInterval("Horloge()", 300);		
    GetIpRouteur(login,pwd);	    
}



function GetIpRouteur(user,password)
{
	var req = null;
	var postParams = "userLogin=" + user + "&passwordLogin=" + password;	  
    var reponse   = '-';
   	ipRouteur="-";
    req = new XMLHttpRequest
    if (req){	  	
        req.open( 'POST', " adresse pour recherche ipRouteur dans BD distante", true );
        req.setRequestHeader( "Content-type", "application/x-www-form-urlencoded" );
        req.setRequestHeader( "Content-length", postParams.length );
        req.setRequestHeader( "Connection", "close" );
        req.onreadystatechange = function()
        {
            if ( req.readyState == 4 && req.status == 200 ){
              userConnected=user;
              ipRouteur= (req.responseText);	
              if (loginConfigLibelles==1){
              	setupConfigLibelles();
              }
              else setup();
            }
            loginEnCours=0;
        }
        req.send( postParams );
    }	  
}


function loginUpConfigLibelles()
{
    var login=document.getElementById("textUser").value;
    var pwd=document.getElementById("textPassword").value;
    var timer=setInterval("Horloge()", 300);		
    loginConfigLibelles=1;
    GetIpRouteur(login,pwd);	    
}

function setupConfigLibelles(){
	loginConfigLibelles=0;
	if (ipRouteur=="-"){
        alert("Login fail");
        return;
    }else
    {    	
    	document.getElementById("loginM3").style.visibility="hidden";			
		document.getElementById("tableSL1_48").style.visibility="visible";	
    }   
}


function updateAllLibelle(){
	indexLibelle=1
	document.getElementById("img"+num_slx).src="images/clock.png";
	if (connected==1) sendMessage("RtextSL1?");	
	//timerUpdatingLibelle=setInterval("HorlogeUpdatingLibelle("+num_slx+")", 100);	
	//timeoutUpdatingLibelle=0;progressUpdatingLibelle=0;
}

function updateLibelle(num_slx){
	if (connected==1) sendMessage("RtextSL"+num_slx+"?");
	
	document.getElementById("img"+num_slx).src="images/clock.png";
	/*var regx = /\'/g;
	var newlibelle=document.getElementById("inputSL"+num_slx+"_new").value;
	newlibelle=newlibelle.replace(regx, ' ');
	if (debug==1) console.log(newlibelle);*/
	timerUpdatingLibelle=setInterval("HorlogeUpdatingLibelle("+num_slx+")", 100);	
	timeoutUpdatingLibelle=0;progressUpdatingLibelle=0;
	//setLibelle(num_slx,newlibelle);	
	
}

function HorlogeUpdatingLibelle(num_slx) {
	var dt=new Date();    
    timeoutUpdatingLibelle++;     
    if (debug==1) console.log(progressUpdatingLibelle);
    if (progressUpdatingLibelle<3){    	
    	progressUpdatingLibelle++;
    }else progressUpdatingLibelle=0;
    document.getElementById("img"+num_slx).src="images/clock" + progressUpdatingLibelle + ".png";      
    if (timeoutUpdatingLibelle>30)
    {    	
        ;//document.getElementById("infoConnection").innerHTML="Connection error";
        document.getElementById("img"+num_slx).src="images/error.png";
        clearInterval(timerUpdatingLibelle);
    }
}


function affResultUpdateLibelle(num_slx,result){	
	clearInterval(timerUpdatingLibelle);
	if (result!="-"){
		document.getElementById("img"+num_slx).src="images/check_mark.png";
		document.getElementById("inputSL"+num_slx+"_new").value=result;
		//document.getElementById("libelleSL"+num_slx).innerHTML="ok";
	}else{
		document.getElementById("img"+num_slx).src="images/error.png";
	}	
}



function addLigneBitsSL(numBit){
	var myligne="";
	myligne+="<tr><td><img src=\"images/exclamation.png\" width=\"20\" height=\"20\"  id=\"imgUpdateLibBitsSL"+numBit+"\" /></td>"
	myligne+="<td><input class=\"inputSLxText\" id=\"inputBitsSL"+numBit+"_text\" type=\"text\" maxlength=\"30\" onkeyup=\"changeTextBitSL("+numBit+",\'inputBitsSL"+numBit+"_text\',event)\"/></td>";
	myligne+="<td class=\"tdBits\"><input type=\"checkbox\" id=\"tableBitsSL"+numBit+"\" checked onclick=\"clickBitsSL("+numBit+")\">"+numBit+"</td></tr>";
	document.write(myligne);
}
function lectureLibellesBit(){
	indexLibelleBit=0;
	var SLsel=document.getElementById("BitsSLxSel").innerHTML;
	var numSL=parseInt(SLsel,10);		
	document.getElementById("imgUpdateLibBitsSL"+indexLibelleBit).src="images/clock.png";		
	sendMessage("RinfoBit"+numSL+"_"+indexLibelleBit+"?");		
	if (debug==1) console.log("RinfoBit"+numSL+"_"+indexLibelleBit+"?");			
}
function changeTextBitSL(numBit,obj_inputBitsSL,evt){
	var SLsel=document.getElementById("BitsSLxSel").innerHTML;
	var numSL=parseInt(SLsel,10);
	var valInput=document.getElementById(obj_inputBitsSL).value;
    var res = valInput.charAt(valInput.length-1);
    var charCode = (evt.which) ? evt.which : evt.keyCode
	var ctrlPressed=0;
 	var altPressed=0;
 	var shiftPressed=0;
 	
 	shiftPressed=evt.shiftKey;
 	altPressed  =evt.altKey;
 	ctrlPressed =evt.ctrlKey;    
	switch	(charCode)
	{
		case 13:
			if (altPressed){
				if (debug==1) console.log("Winfobit"+numSL+"_"+numBit+"="+(valInput));
				if (connected==1) {
					document.getElementById("imgUpdateLibBitsSL"+numBit).src="images/clock.png";
					sendMessage("RinfoBit"+numSL+"_"+numBit+"?");		
						
				}
			}else{
				if (debug==1) console.log("Winfobit"+numSL+"_"+numBit+"="+(valInput));
				if (connected==1) {			
					document.getElementById("imgUpdateLibBitsSL"+numBit).src="images/clock.png";		
					sendMessage("Winfobit"+numSL+"_"+numBit+"="+(valInput));
								
				}		
			}
			
		break;
	}	  	
}

function clickBitsSL(numBit){
	var SLsel=document.getElementById("BitsSLxSel").innerHTML;
	var numSL=parseInt(SLsel,10);
	var newValue;
	if (document.getElementById("tableBitsSL"+numBit).checked){
    	//if (debug==1) console.log("SL"+numSL+"."+numBit+"=1");
    	newValue=blocSlx[numSL]|(1<<numBit);
    }else {
    	//if (debug==1) console.log("SL"+numSL+"."+numBit+"=0");
    	var tempMask=(1<<numBit);
    	tempMask=~tempMask;    	
    	newValue=blocSlx[numSL]&tempMask;
    }
	sendCdeIO("m3_Ww(" + numSL + "," + newValue + ")"); 
	
}

function hidedetailBitsSL(){
	document.getElementById("detailBitsSL").style.visibility="hidden";
}

function showdetailBitsSL(numSL){
	if (connected==1){
		var posXY=getScrollXY();		
		var rectBin = document.getElementById("SL"+numSL+"_Bin").getBoundingClientRect();
		var rectDetailsBitsSL = document.getElementById("detailBitsSL").getBoundingClientRect();
		var rectBloc_SL25_48 = document.getElementById("Bloc_SL25_48").getBoundingClientRect();
		if (debug==1) console.log("posY= "+rectDetailsBitsSL.width);
		//posdetailBitsSL(20,mouseY+posXY[1]-10);-Math.floor(rectDetailsBitsSL/2)+60
		posdetailBitsSL(rectBloc_SL25_48.left+rectBin.left-rectDetailsBitsSL.width-posXY[0]-5,rectBin.top+posXY[1]-55);
		showBitsSL(numSL);
		
		//if (debug==1) console.log("modif bits SL " +numSL);		
		document.getElementById("BitsSLxSel").innerHTML=numSL;
		lectureLibellesBit();
		document.getElementById("detailBitsSL").style.visibility="visible";
	}	
}

function showBitsSL(numSL){
	document.getElementById("titredetailBitsSL").innerHTML="SL nº " + numSL;
	
	for (var i=0; i<=15;i++){
		if ((blocSlx[numSL]&(1<<i))>0){
			document.getElementById("tableBitsSL"+i).checked=true;
		}else
			document.getElementById("tableBitsSL"+i).checked=false;
		document.getElementById("tableBitsSL"+i).disabled=(numSL>=25);			
	}
}


