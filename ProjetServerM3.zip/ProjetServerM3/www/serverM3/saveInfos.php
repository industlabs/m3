<?php 

define( "DATABASE_SERVER", "localhost" );
define( "DATABASE_USERNAME", "root" );
define( "DATABASE_PASSWORD", "your password" );
define( "DATABASE_NAME", "serverM3" );


$ReturnResult= "Erreur";	
$dateheure=(new \DateTime())->format('Y-m-d H:i:s');

$link = mysql_connect(DATABASE_SERVER, DATABASE_USERNAME, DATABASE_PASSWORD);
if (!$link) {
	die('Could not connect: ' . mysql_error());
}
else
{
	$mysqli = new mysqli(DATABASE_SERVER, DATABASE_USERNAME, DATABASE_PASSWORD, DATABASE_NAME);
	if (!$mysqli) 
	{
		//die('Could not select database: ' . mysql_error());  
	}
	else
	{
		$db_selected = mysql_select_db(DATABASE_NAME);
		if (!$db_selected) 
		{
			die('Could not select database: ' . mysql_error());
		}
		else
		{
			for ($i = 25; $i <= 38; $i++) {
				$adrSL="SL".$i;
				if (isset($_POST[$adrSL])){
					$valSL=(htmlentities($_POST[$adrSL]));
					$query="INSERT INTO serverM3.HistoSL (numSL, valeur, dateHeure) VALUES ('".$i."', '".$valSL."', '".$dateheure."')";
					$result=mysql_query($query);	
				}
			}			
			$ReturnResult= "OK";		
		}			
	}
mysql_close($link);
//echo ($ReturnResult);
}

function mysql_entities_fix_string($string)
{
	return htmlentities(mysql_fix_string($string));
}

function mysql_fix_string($string)
{
if (get_magic_quotes_gpc()) $string = stripslashes($string);
return mysql_real_escape_string($string);
}

function check_input($value)
{
// Stripslashes
if (get_magic_quotes_gpc())
  {
  $value = stripslashes($value);
  }
// Quote if not a number
if (!is_numeric($value))
  {
  $value = "'" . mysql_real_escape_string($value) . "'";
  }
return $value;
}
?>
