<?php 

define( "DATABASE_SERVER", "localhost" );
define( "DATABASE_USERNAME", "root" );
define( "DATABASE_PASSWORD", "your password" );
define( "DATABASE_NAME", "serverM3" );

$slx=(htmlentities($_POST["slx"]));
$slx_libelle=htmlentities(utf8_encode(addslashes($_POST["slx_libelle"])));
$Return_slx_libelle="-";

$link = mysql_connect(DATABASE_SERVER, DATABASE_USERNAME, DATABASE_PASSWORD);
if (!$link) {
	die('Could not connect: ' . mysql_error());
}
else
{
	$mysqli = new mysqli(DATABASE_SERVER, DATABASE_USERNAME, DATABASE_PASSWORD, DATABASE_NAME);
	if (!$mysqli) 
	{
		//die('Could not select database: ' . mysql_error());  
	}
	else
	{
		$db_selected = mysql_select_db(DATABASE_NAME);
		if (!$db_selected) 
		{
			die('Could not select database: ' . mysql_error());
		}
		else
		{			
			$query="SELECT * FROM libellesSLx WHERE SL=".$slx;	
			$result=mysql_query($query);			
			$num_results=mysql_num_rows($result);
			//echo $num_results. " lignes" . "<br>";
			if ($num_results>0)
			{				
				$sqlQuery="UPDATE libellesSLx SET libelle = '" .$slx_libelle. "'WHERE SL=".$slx;
				$sqlResult=mysql_query($sqlQuery);		
			}	
			$Return_slx_libelle= utf8_decode(html_entity_decode(stripslashes($slx_libelle)));		
		}			
	}
mysql_close($link);
echo ($Return_slx_libelle);
}

function mysql_entities_fix_string($string)
{
	return htmlentities(mysql_fix_string($string));
}

function mysql_fix_string($string)
{
if (get_magic_quotes_gpc()) $string = stripslashes($string);
return mysql_real_escape_string($string);
}

function check_input($value)
{
// Stripslashes
if (get_magic_quotes_gpc())
  {
  $value = stripslashes($value);
  }
// Quote if not a number
if (!is_numeric($value))
  {
  $value = "'" . mysql_real_escape_string($value) . "'";
  }
return $value;
}
?>
